//
//  Colors.swift
//  Banorte E-Pocket
//
//  Created by Chema Padilla Fdez on 24/04/24.
//

import SwiftUI

extension Color {
    
    public static let Rojo: Color = Color(UIColor(red: 0.79, green: 0.07, blue: 0.19, alpha: 1.00))
    
    public static let Naranja: Color = Color(UIColor(red: 1.00, green: 0.62, blue: 0.16, alpha: 1.00))
    
    public static let GrisClaro: Color = Color(UIColor(red: 0.95, green: 0.95, blue: 0.95, alpha: 1.00))
    
    public static let Gris: Color = Color(UIColor(red: 0.67, green: 0.67, blue: 0.67, alpha: 1.00))
    
    public static let Verde: Color = Color(UIColor(red: 0.40, green: 0.78, blue: 0.46, alpha: 1.00))
    
    public static let Morado: Color = Color(UIColor(red: 0.45, green: 0.40, blue: 0.78, alpha: 1.00))
    
    public static let Azul: Color = Color(UIColor(red: 0.16, green: 0.70, blue: 1.00, alpha: 1.00))
}
