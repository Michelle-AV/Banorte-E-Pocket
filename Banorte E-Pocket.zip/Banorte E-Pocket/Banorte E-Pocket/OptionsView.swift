//
//  OptionsView.swift
//  Banorte E-Pocket
//
//  Created by Chema Padilla Fdez on 24/04/24.
//

import SwiftUI

struct OptionsView: View {
    
    private var UISW: CGFloat = UIScreen.main.bounds.width
    private var UISH: CGFloat = UIScreen.main.bounds.height
    
    @State var isTap1: Bool = true
    @State var isTap2: Bool = false
    @State var isTap3: Bool = false
    @State var isTap4: Bool = false
    
    @State var isAct: Bool = false
    
    var body: some View {
        ZStack{
            
            if(isTap1){
                MenuView(isAct: $isAct)
            } else if (isTap2){
                ContentView()
            } else if (isTap3){
                GameListView()
            } else if (isTap4){
                ProfileView()
            }
            
            RoundedRectangle(cornerRadius: 15)
                .foregroundColor(.white)
                .frame(width: UISW * 0.9, height: 80)
                .position(x: UISW * 0.5, y: UISH * 0.92)
            
            ZStack{
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color.Rojo)
                    .frame(width: isTap1 ? 120 : 0, height: 45)
                
                Image(systemName: "house.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30)
                    .foregroundColor(isTap1 ? .white : Color.Gris)
                    .offset(x: isTap1 ? -35 : 0)
                
                Text("Inicio")
                    .font(.custom("Poppins-Regular", size: 14))
                    .foregroundStyle(.white)
                    .offset(x: 10)
                    .opacity(isTap1 ? 1 : 0)
                
            }.position(x: isTap1 ? UISW * 0.23 : UISW * 0.15, y: UISH * 0.92)
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isTap1 = true
                        isTap2 = false
                        isTap3 = false
                        isTap4 = false
                    }
                }
            
            ZStack{
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color.Rojo)
                    .frame(width: isTap2 ? 120 : 0, height: 45)

                Image(systemName: "message.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30)
                    .foregroundColor(isTap2 ? .white : Color.Gris)
                    .offset(x: isTap2 ? -35 : 0)
                
                Text("Foro")
                    .font(.custom("Poppins-Regular", size: 14))
                    .foregroundStyle(.white)
                    .offset(x: 10)
                    .opacity(isTap2 ? 1 : 0)
                
            }.position(x: UISW * 0.4, y: UISH * 0.92)
                .offset(x: isTap1 ? 30 : 0)
                .offset(x: isTap3 ? -30 : 0)
                .offset(x: isTap4 ? -30 : 0)
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isTap1 = false
                        isTap2 = true
                        isTap3 = false
                        isTap4 = false
                    }
                }
            
            ZStack{
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color.Rojo)
                    .frame(width: isTap3 ? 120 : 0, height: 45)

                Image(systemName: "gamecontroller.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 30)
                    .foregroundColor(isTap3 ? .white : Color.Gris)
                    .offset(x: isTap3 ? -35 : 0)
                
                Text("Foro")
                    .font(.custom("Poppins-Regular", size: 14))
                    .foregroundStyle(.white)
                    .offset(x: 10)
                    .opacity(isTap3 ? 1 : 0)
                
            }.position(x: UISW * 0.65, y: UISH * 0.92)
                .offset(x: isTap2 ? 0 : 0)
                .offset(x: isTap3 ? -20 : 0)
                .offset(x: isTap4 ? -50 : 0)
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isTap1 = false
                        isTap2 = false
                        isTap3 = true
                        isTap4 = false
                    }
                }
            
            ZStack{
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color.Rojo)
                    .frame(width: isTap4 ? 120 : 0, height: 45)

                Image(systemName: "person.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 25)
                    .foregroundColor(isTap4 ? .white : Color.Gris)
                    .offset(x: isTap4 ? -35 : 0)
                
                Text("Foro")
                    .font(.custom("Poppins-Regular", size: 14))
                    .foregroundStyle(.white)
                    .offset(x: 10)
                    .opacity(isTap4 ? 1 : 0)
                
            }.position(x: UISW * 0.8, y: UISH * 0.92)
                .offset(x: isTap3 ? 10 : 0)
                .offset(x: isTap4 ? -10 : 0)
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        isTap1 = false
                        isTap2 = false
                        isTap3 = false
                        isTap4 = true
                    }
                }
            
            if(isAct){
                ActivityView(isAct: $isAct)
                    .padding(.top, 60)
            }
        }.ignoresSafeArea()
    }
}

#Preview {
    OptionsView()
}
