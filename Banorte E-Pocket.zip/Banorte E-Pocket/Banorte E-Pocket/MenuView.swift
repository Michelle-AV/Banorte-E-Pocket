//
//  MenuView.swift
//  Banorte E-Pocket
//
//  Created by Chema Padilla Fdez on 24/04/24.
//

import SwiftUI

struct MenuView: View {
    
    @Binding var isAct: Bool
    
    var UISW: CGFloat = UIScreen.main.bounds.width
    var UISH: CGFloat = UIScreen.main.bounds.height
    
    @State var isTap1: Bool = true
    @State var isTap2: Bool = false
    @State var isTap3: Bool = false
    @State var isTap4: Bool = false
    
    var body: some View {
        ZStack{
            Color.GrisClaro
                .allowsHitTesting(false)
            
            ScrollView(.vertical, showsIndicators: false){
                VStack{
                    Image("Dashboard")
                        .resizable()
                        .scaledToFit()
                        .frame(width: UISW * 0.93)
                        .offset(x: 5)
                        .position(x: UISW * 0.5, y: UISH * 0.42)
                    
                    
                    ZStack{
                        Text("Cursos")
                            .font(.custom("Poppins-Bold", size: 24))
                            .foregroundStyle(.black)
                            .position(x: UISW * 0.17, y: UISH * 0.53)
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 15)
                                .foregroundColor(isTap1 ? Color.Naranja : .white)
                                .frame(width: 155, height: 40)
                                .shadow(color: !isTap1 ? Color.Gris.opacity(0) : Color.Gris.opacity(0.4), radius: 4, x: 5, y: 5)
                            
                            HStack {
                                Image(systemName: "checkmark.rectangle.stack.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                    .foregroundColor(isTap1 ? .white : Color.Naranja)
                                
                                Text("Todos los cursos")
                                    .font(.custom("Poppins-Regular", size: 11))
                                    .foregroundStyle(isTap1 ? .white : .black)
                            }
                            
                        }.position(x: UISW * 0.26, y: UISH * 0.58)
                            .onTapGesture {
                                withAnimation(.easeInOut(duration: 0.3)){
                                    isTap1 = true
                                    isTap2 = false
                                    isTap3 = false
                                    isTap4 = false
                                }
                            }
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 15)
                                .foregroundColor(isTap2 ? Color.Verde : .white)
                                .frame(width: 155, height: 40)
                                .shadow(color: isTap2 ? Color.Gris.opacity(0.4) : Color.Gris.opacity(0), radius: 4, x: 5, y: 5)
                            
                            HStack {
                                Image(systemName: "puzzlepiece.extension.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                    .foregroundColor(isTap2 ? .white : Color.Verde)
                                
                                Text("Nivel principiante")
                                    .font(.custom("Poppins-Regular", size: 11))
                                    .foregroundStyle(isTap2 ? .white : .black)
                            }
                            
                        }.position(x: UISW * 0.75, y: UISH * 0.58)
                            .onTapGesture {
                                withAnimation(.easeInOut(duration: 0.3)){
                                    isTap1 = false
                                    isTap2 = true
                                    isTap3 = false
                                    isTap4 = false
                                }
                            }
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 15)
                                .foregroundColor(isTap3 ? Color.Morado : .white)
                                .frame(width: 155, height: 40)
                                .shadow(color: !isTap3 ? Color.Gris.opacity(0) : Color.Gris.opacity(0.4), radius: 4, x: 5, y: 5)
                            
                            HStack {
                                Image(systemName: "star.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                    .foregroundColor(isTap3 ? .white : Color.Morado)
                                
                                Text("Nivel intermedio")
                                    .font(.custom("Poppins-Regular", size: 11))
                                    .foregroundStyle(isTap3 ? .white : .black)
                            }
                            
                        }.position(x: UISW * 0.26, y: UISH * 0.64)
                            .onTapGesture {
                                withAnimation(.easeInOut(duration: 0.3)){
                                    isTap1 = false
                                    isTap2 = false
                                    isTap3 = true
                                    isTap4 = false
                                }
                            }
                        
                        ZStack {
                            RoundedRectangle(cornerRadius: 15)
                                .foregroundColor(isTap4 ? Color.Azul : .white)
                                .frame(width: 155, height: 40)
                                .shadow(color: isTap4 ? Color.Gris.opacity(0.4) : Color.Gris.opacity(0), radius: 4, x: 5, y: 5)
                            
                            HStack {
                                Image(systemName: "play.square.fill")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 20)
                                    .foregroundColor(isTap4 ? .white : Color.Azul)
                                
                                Text("Nivel avanzado")
                                    .font(.custom("Poppins-Regular", size: 11))
                                    .foregroundStyle(isTap4 ? .white : .black)
                            }
                            
                        }.position(x: UISW * 0.75, y: UISH * 0.64)
                            .onTapGesture {
                                withAnimation(.easeInOut(duration: 0.3)){
                                    isTap1 = false
                                    isTap2 = false
                                    isTap3 = false
                                    isTap4 = true
                                }
                            }
                    }.offset(y: UISW * -0.4)
                    
                    ScrollView(.horizontal, showsIndicators: false){
                        if(isTap1){
                            HStack(spacing: 20){
                                Image("n1-1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n1-2")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n1-3")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n2-1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                    .onTapGesture {
                                        withAnimation(.easeInOut(duration: 0.5)) {
                                            isAct = true
                                        }
                                    }
                                
                                Image("n2-2")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 175)
                                    .offset(y: -6)
                                
                                Image("n2-3")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n3-1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n3-2")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n3-3")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                            }
                        } else if(isTap2){
                            HStack(spacing: 20){
                                Image("n1-1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n1-2")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n1-3")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                            }
                        } else if(isTap3){
                            HStack(spacing: 20){
                                Image("n2-1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                    .onTapGesture {
                                        withAnimation(.easeInOut(duration: 0.5)) {
                                            isAct = true
                                        }
                                    }
                                
                                Image("n2-2")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 175)
                                    .offset(y: -6)
                                
                                Image("n2-3")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                            }
                        } else if(isTap4){
                            HStack(spacing: 20){
                                Image("n3-1")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n3-2")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                                
                                Image("n3-3")
                                    .resizable()
                                    .scaledToFit()
                                    .frame(width: 145)
                            }
                        }
                    }
                    .padding(.top, 380)
                    .padding(.leading, 20)
                }
                
                Rectangle()
                    .foregroundColor(Color.GrisClaro)
                    .frame(width: UISW, height: UISH * 0.15)
            }
            
            Rectangle()
                .foregroundColor(.white)
                .frame(height: UISH * 0.5)
                .position(x: UISW * 0.5, y: UISH * -0.01)
            
            Text("Bienvenida,")
                .font(.custom("Poppins-SemiBold", size: 19))
                .foregroundStyle(Color.Gris)
                .position(x: UISW * 0.25, y: UISH * 0.1)
            
            Text("Michelle Ayala")
                .font(.custom("Poppins-SemiBold", size: 25))
                .foregroundStyle(.black)
                .position(x: UISW * 0.34, y: UISH * 0.14)
            
            Text("25 de abril del 2024")
                .font(.custom("Poppins-Regular", size: 12))
                .foregroundStyle(Color.Gris)
                .position(x: UISW * 0.26, y: UISH * 0.2)
            
            Image("mich-face")
                .resizable()
                .scaledToFit()
                .frame(width: 60)
                .position(x: UISW * 0.8, y: UISH * 0.12)
            
            HStack {
                Image("spain")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20)
                
                Text("Spanish")
                    .font(.custom("Poppins-Medium", size: 13))
                    .foregroundColor(.black)
                Text(">")
                    .font(.custom("Poppins-Bold", size: 15))
                    .rotationEffect(.degrees(90))
                    .foregroundColor(.black)
            }.position(x: UISW * 0.8, y: UISH * 0.22)
            
            RoundedRectangle(cornerRadius: 0)
                .foregroundColor(Color.GrisClaro)
                .frame(width: UISW, height: 70)
                .position(x: UISW * 0.5, y: UISH * 0.28)
            
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(.white)
                    .frame(width: UISW * 0.93, height: 40)
                
                Image(systemName: "mic.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 13)
                    .foregroundColor(Color.Gris)
                    .offset(x: 155)
                
                Text("Busca un tema...")
                    .font(.custom("Poppins-Medium", size: 15))
                    .foregroundStyle(Color.Gris)
                    .offset(x: -60)
                    .opacity(0.7)
                
                Image(systemName: "magnifyingglass")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 20)
                    .foregroundColor(Color.Gris)
                    .offset(x: -155)
            }.position(x: UISW * 0.5, y: UISH * 0.28)
        }.ignoresSafeArea()
    }
}
//
//#Preview {
//    MenuView()
//}
