//
//  SwiftUIView.swift
//  Banorte E-Pocket
//
//  Created by Chema Padilla Fdez on 24/04/24.
//

import SwiftUI

struct SwiftUIView: View {
    var body: some View {
        ScrollView{
            VStack{
                Rectangle()
                    .frame(width: 100, height: 150)
                Rectangle()
                    .frame(width: 100, height: 150)
                ScrollView(.horizontal, showsIndicators: false){
                    if(true){
                        HStack{
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Verde)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Verde)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Verde)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Morado)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Morado)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Morado)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Azul)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Azul)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Azul)
                                .frame(width: 120, height: 150)
                        }
                    } else if(true){
                        HStack{
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Verde)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Verde)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Verde)
                                .frame(width: 120, height: 150)
                        }
                    } else if(true){
                        HStack{
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Morado)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Morado)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Morado)
                                .frame(width: 120, height: 150)
                        }
                    } else if(true){
                        HStack{
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Azul)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Azul)
                                .frame(width: 120, height: 150)
                            
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundColor(Color.Azul)
                                .frame(width: 120, height: 150)
                        }
                    }
                }
            }
        }
    }
}

#Preview {
    SwiftUIView()
}
