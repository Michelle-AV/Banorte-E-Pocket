//
//  MainView3.swift
//  Banorte E-Pocket
//
//  Created by Chema Padilla Fdez on 24/04/24.
//

import SwiftUI

struct MainView3: View {
    
    private var UISW: CGFloat = UIScreen.main.bounds.width
    private var UISH: CGFloat = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack {
            Color.Rojo
            
            VStack {
                Text("Planifica")
                    .font(.custom("Poppins-Bold", size: 50))
                    .foregroundStyle(.white)
                    .offset(x: -54)
                
                Text("Transforma tus sueños en metas realizables y alcanza el éxito financiero.")
                    .font(.custom("Poppins-Regular", size: 15))
                    .foregroundStyle(.white)
                    .offset(x: -16)
                    .frame(width: 330)

            }.position(x: UISW * 0.5, y: UISH * 0.15)
                .padding(.horizontal, 10)
            
            RoundedRectangle(cornerRadius: 30)
                .foregroundColor(.white)
                .frame(width: 40, height: 5)
                .position(x: UISW * 0.16, y: UISH * 0.235)
            
            RoundedRectangle(cornerRadius: 30)
                .foregroundColor(.white)
                .frame(width: 18, height: 5)
                .position(x: UISW * 0.25, y: UISH * 0.235)
            
            RoundedRectangle(cornerRadius: 30)
                .foregroundColor(.white)
                .frame(width: 17, height: 5)
                .position(x: UISW * 0.313, y: UISH * 0.235)
            
            
            ZStack {
                RoundedRectangle(cornerRadius: 10)
                    .foregroundColor(Color.Naranja)
                .frame(width: 80, height: 80)
                
                Text(">")
                    .font(.custom("Poppins-SemiBold", size: 70))
                    .foregroundStyle(.white)
            }.position(x: UISW * 0.78, y: UISH * 0.9)
        }.ignoresSafeArea()
    }
}
#Preview {
    MainView3()
}
