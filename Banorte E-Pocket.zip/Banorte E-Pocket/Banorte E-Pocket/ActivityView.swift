//
//  ActividadView.swift
//  perfil
//
//  Created by Michelle Ayala on 24/04/24.
//

import SwiftUI

struct ActivityView: View {
    
    @Binding var isAct: Bool
    
    var UISW: CGFloat = UIScreen.main.bounds.width
    var UISH: CGFloat = UIScreen.main.bounds.height
    
    var body: some View {
        
        ZStack {
            
            Color(uiColor: UIColor(red: 0.45, green: 0.40, blue: 0.78, alpha: 1.00))
            
            Image("act1")
                .resizable()
                .frame(width: UISW * 1, height: UISH * 0.37)
                .position(x: UISW * 0.5, y: UISH * 0.116)
            
            RoundedRectangle(cornerRadius: 40)
                .frame(width: 394, height: 640)
                .foregroundColor(.white)
                .padding(.bottom)
                .position(x: UISW * 0.5, y: UISH * 0.567)

            VStack {
                
                VStack (spacing: 20){
                    Text("Este módulo te proporcionará las habilidades esenciales para manejar las herramientas básicas del dinero digital. Aprenderás a usar aplicaciones como CoDi y DiMO para realizar pagos y recibir dinero de manera rápida y segura.")
                        .foregroundColor(.black)
                    
                    Text("Además, recibirás consejos prácticos sobre cómo protegerte contra el fraude y garantizar la seguridad en tus transacciones financieras en línea.")
                        .padding(.leading, 10)
                        .foregroundColor(.black)
                    
                    
                    Group {
                        Image("pop1")
                            .resizable()
                        Image("pop2")
                            .resizable()
                        Image("pop3")
                            .resizable()
                    }
                    .frame(width: 330, height: 100)
                }
                .font(.custom("Poppins-Regular", size: 15))
                .frame(width: 330, height: 900)
                .padding(.top, 20)
                
            }
            .padding(.bottom, -160)
            
            Image(systemName: "xmark.circle.fill")
                .resizable()
                .scaledToFit()
                .frame(width: 40)
                .foregroundColor(.white)
                .position(x: UISW * 0.12, y: UISH * 0)
                .onTapGesture {
                    withAnimation(.easeInOut(duration: 0.5)) {
                        isAct = false
                    }
                }
        }.ignoresSafeArea()
    }
}

//#Preview {
//    ActivityView()
//}
