//
//  Banorte_E_PocketApp.swift
//  Banorte E-Pocket
//
//  Created by Chema Padilla Fdez on 24/04/24.
//

import SwiftUI

@main
struct Banorte_E_PocketApp: App {
    var body: some Scene {
        WindowGroup {
            MainView()
        }
    }
}
