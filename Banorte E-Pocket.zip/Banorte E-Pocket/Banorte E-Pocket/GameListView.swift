
import SwiftUI

struct GameListView: View {
    private var UISW: CGFloat = UIScreen.main.bounds.width
    private var UISH: CGFloat = UIScreen.main.bounds.height
    
    @State var isTapped = false
    
    var body: some View {
        ZStack{
            Color.GrisClaro
            
            Circle()
                .stroke(Color.Rojo.opacity(0.14) , lineWidth: 35)
                .frame(width: 210, height: 210)
                .position(x: UISW * 1, y: UISH * 0.16)
                .zIndex(1)
            
            Circle()
                .stroke(Color.Morado.opacity(0.1) , lineWidth: 35)
                .frame(width: 210, height: 210)
                .position(x: UISW * 0.01, y: UISH * 0.45)
                .zIndex(1)
            
            ZStack{
                
                Rectangle()
                    .foregroundColor(.white)
                    .frame(width: 393, height: 500)
                
                HStack{
                    Text("¡Practica aquí!")
                        .foregroundStyle(Color.black)
                        .frame(width: 300)
                        .font(.custom("Poppins-Bold", size: 30))
                        .foregroundColor(.black)
                    
                    Image("GAME")
                        .resizable()
                        .frame(width: 60, height: 60)
                    
                }.offset(y: 120)
                
                Text("En esta sección encontrarás mini tareas diseñadas para ayudarte a practicar y familiarizarte con el uso del código QR de Banorte y otras funciones financieras clave.")
                    .font(.custom("Poppins-Regular", size: 11))
                    .foregroundStyle(Color.black)
                    .frame(width: 330)
                    .offset(y: 200)                
            }.position(x: UISW * 0.5, y: UISH * -0.03)
            .zIndex(3)
            ZStack{
                
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 350, height: 120)
                    .foregroundColor(.white)
                    .padding(.bottom)
                    .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                    .overlay{
                        ZStack{
                            Image("GAME1")
                                .resizable()
                                .frame(width: 75, height: 75)
                                .position(x:UISW * 0.12, y: UISH * 0.067 )
                            
                            VStack{
                                Text("Desafío financiero")
                                    .font(.custom("Poppins-Bold", size: 16))
                                    .foregroundColor(.black)
                                    .position(x: UISW * 0.222, y: UISH * 0.05)
                                
                                Text("Escenario interactivo donde tendras que tomar decisiones financieras utilizando tanto dinero digital como efectivo. Practica mediante la toma de desiciones de la opción que consideres mas ventajosa.")
                                    .font(.custom("Poppins-Regular", size: 8))
                                    .foregroundColor(.black)
                                    .frame(width: 240)
                                    .position(x: UISW * 0.335, y: UISH * 0.014)
                                
                            }.position(x:UISW * 0.665, y: UISH * 0.065 )
                            
                            Image("POINTS")
                                .resizable()
                                .frame(width: 40, height: 43)
                                .position(x: UISW * 0.8, y: UISH * 0.14)
                        }
                    }
                    .position(x:UISW * 0.5, y: UISH * 0.13)
                
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 350, height: 120)
                    .foregroundColor(.white)
                    .padding(.bottom)
                    .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                    .overlay{
                        ZStack{
                            Image("GAME2")
                                .resizable()
                                .frame(width: 75, height: 75)
                                .position(x:UISW * 0.12, y: UISH * 0.067 )
                            
                            VStack{
                                Text("Aventura Digital CoDI")
                                    .font(.custom("Poppins-Bold", size: 16))
                                    .foregroundColor(.black)
                                    .position(x: UISW * 0.256, y: UISH * 0.05)
                                
                                Text("Simulación que te permitirá experimentar el proceso de realizar transacciones utilizando CoDI (Cobro Digital). Asumirás el papel de un personaje virtual que debe utilizar CoDi para realizar pagos yresolver situaciones financieras.")
                                    .font(.custom("Poppins-Regular", size: 8))
                                    .foregroundColor(.black)
                                    .frame(width: 240)
                                    .position(x: UISW * 0.335, y: UISH * 0.014)
                                
                            }.position(x:UISW * 0.665, y: UISH * 0.065 )
                            
                            Image("POINTS")
                                .resizable()
                                .frame(width: 40, height: 43)
                                .position(x: UISW * 0.8, y: UISH * 0.14)
                        }
                    }
                    .position(x:UISW * 0.5, y: UISH * 0.315)
                    .onTapGesture {
                        
                        withAnimation(.easeIn){
                            isTapped.toggle()
                        }
                        
                    }
                
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 350, height: 120)
                    .foregroundColor(.white)
                    .padding(.bottom)
                    .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                    .overlay{
                        ZStack{
                            Image("GAME3")
                                .resizable()
                                .frame(width: 75, height: 75)
                                .position(x:UISW * 0.12, y: UISH * 0.067 )
                            
                            VStack{
                                Text("Finanzas maestras")
                                    .font(.custom("Poppins-Bold", size: 16))
                                    .foregroundColor(.black)
                                    .position(x: UISW * 0.235, y: UISH * 0.05)
                                
                                Text("Uso de una tarjeta de crédito para gestionar tus gastos diarios y establecer un historial crediticio es la meta. Se te presentarán varias opciones de tarjetas de crédito, cada una con diferentes tasas de interés, límites de crédito y beneficios asociados.")
                                    .font(.custom("Poppins-Regular", size: 8))
                                    .foregroundColor(.black)
                                    .frame(width: 240)
                                    .position(x: UISW * 0.335, y: UISH * 0.014)
                                
                            }.position(x:UISW * 0.665, y: UISH * 0.065 )
                            
                            Image("POINTS")
                                .resizable()
                                .frame(width: 40, height: 43)
                                .position(x: UISW * 0.8, y: UISH * 0.14)
                        }
                    }
                    .position(x:UISW * 0.5, y: UISH * 0.501)
                
                
                
                
            }.position(x: UISW * 0.5, y:UISH * 0.755)
                .zIndex(2)
            
            if isTapped {
                
                CoDIPopUpView()
                    .zIndex(4)
                    .onTapGesture {
                        isTapped.toggle()
                        
                    }
            }
        }.ignoresSafeArea()
    }
}

#Preview {
    GameListView()
}
