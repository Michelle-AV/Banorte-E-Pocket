//
//  ContentView.swift
//  Banorte E-Pocket
//
//  Created by Chema Padilla Fdez on 24/04/24.
//

import SwiftUI

struct MainView: View {
    
    private var UISW: CGFloat = UIScreen.main.bounds.width
    private var UISH: CGFloat = UIScreen.main.bounds.height
    
    @State var isView1: Bool = true
    @State var isView2: Bool = false
    @State var isView3: Bool = false
    @State var isFinal: Bool = false
    
    var body: some View {
        ZStack {
            
            OptionsView()
            ZStack{
                Color.Rojo
                
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(.white)
                    .frame(width: isView1 ? 40 : 18, height: 5)
                    .position(x: isView1 ? UISW * 0.16 : UISW * 0.135, y: UISH * 0.235)
                
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(.white)
                    .frame(width: isView2 ? 40 : 18, height: 5)
                    .position(x: !isView2 ? isView3 ? UISW * 0.2 : UISW * 0.25 : UISW * 0.225, y: UISH * 0.235)
                
                RoundedRectangle(cornerRadius: 30)
                    .foregroundColor(.white)
                    .frame(width: isView3 ? 40 : 18, height: 5)
                    .position(x: !isView3 ? UISW * 0.313 : UISW * 0.288, y: UISH * 0.235)
                
                ZStack{
                    VStack {
                        Text("Conoce")
                            .font(.custom("Poppins-Bold", size: 50))
                            .foregroundStyle(.white)
                            .offset(x: -70)
                        
                        Text("Empodérate con conocimiento financiero de primera mano.")
                            .font(.custom("Poppins-Regular", size: 15))
                            .foregroundStyle(.white)
                            .offset(x: -5)
                            .frame(width: 330)

                    }.position(x: UISW * 0.5, y: UISH * 0.15)
                        .padding(.horizontal, 10)
                    
                    Image("num1")
                        .resizable().scaledToFit()
                        .frame(width: 400)
                }.offset(x: isView1 ? 0 : -500)
                
                ZStack{
                    VStack {
                        Text("Organiza")
                            .font(.custom("Poppins-Bold", size: 50))
                            .foregroundStyle(.white)
                            .offset(x: -50)
                        
                        Text("Gestiona tus ingresos y gastos de manera eficiente.")
                            .font(.custom("Poppins-Regular", size: 15))
                            .foregroundStyle(.white)
                            .offset(x: -35)
                            .frame(width: 330)

                    }.position(x: UISW * 0.5, y: UISH * 0.15)
                        .padding(.horizontal, 10)
                    Image("num2")
                        .resizable().scaledToFit()
                        .frame(width: 400)
                }.offset(x: isView1 ? 500 : (isView2 ? 0 : -500))
                
                ZStack{
                    VStack {
                        Text("Planifica")
                            .font(.custom("Poppins-Bold", size: 50))
                            .foregroundStyle(.white)
                            .offset(x: -54)
                        
                        Text("Transforma tus sueños en metas realizables y alcanza el éxito financiero.")
                            .font(.custom("Poppins-Regular", size: 15))
                            .foregroundStyle(.white)
                            .offset(x: -16)
                            .frame(width: 330)

                    }.position(x: UISW * 0.5, y: UISH * 0.15)
                        .padding(.horizontal, 10)
                    Image("num3")
                        .resizable().scaledToFit()
                        .frame(width: 400)
                }.offset(x: isView1 ? 500 : isView2 ? 500 : isView3 ? 0 : -500)
                
                ZStack {
                    RoundedRectangle(cornerRadius: isView3 ? 20 : 10)
                        .foregroundColor(Color.Naranja)
                        .frame(width: isView3 ? 180 : 60, height: isView3 ? 60 : 60)
                    
                    Text(isView3 ? "¡Empecemos!" : ">")
                        .font(.custom("Poppins-SemiBold", size: isView3 ? 20 : 50))
                        .foregroundStyle(.white)
                }.position(x: isView3 ? UISW * 0.65 : UISW * 0.78, y: UISH * 0.9)
                    .onTapGesture {
                        withAnimation(.spring(duration: 0.5)) {
                            if(isView1) {
                                isView1 = false
                                isView2 = true
                            } else if(isView2) {
                                isView2 = false
                                isView3 = true
                            } else {
                                isView3 = false
                                isFinal = true
                            }
                        }
                    }
            }.offset(y: isFinal ? UISH * 2 : 0)
            
        }.ignoresSafeArea()
    }
}

#Preview {
    MainView()
}
