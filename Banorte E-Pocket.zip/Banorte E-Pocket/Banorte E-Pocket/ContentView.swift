
import SwiftUI

struct ContentView: View {
    
    private var UISW: CGFloat = UIScreen.main.bounds.width
    private var UISH: CGFloat = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack{
            Color.GrisClaro

            Circle()
                .stroke(Color.Morado.opacity(0.1) , lineWidth: 35)
                .frame(width: 210, height: 210)
                .position(x: UISW * 0.01, y: UISH * 0.05)
            
            
            HStack{
                Text("BanComunidad")
                    .foregroundStyle(Color.black)
                    .frame(width: 300)
                    .font(.custom("Poppins-Bold", size: 30))
                    .foregroundColor(.black)
                
                Image("Group_42")
                    .resizable()
                    .frame(width: 60, height: 60)
                    .position(x:UISW * 0.1, y: UISH * 0.48)
                
            }.position(x: UISW * 0.48, y: UISH * 0.13)
            
            Text("¡Bienvenido al foro de testimonios de nuestra aplicación!")
                .foregroundStyle(Color.black)
                .font(.custom("Poppins-Bold", size: 12))
                .frame(width: 500)
                .position(x:UISW * 0.5, y: UISH * 0.2)
                
            ZStack{
                RoundedRectangle(cornerRadius: 10)
                    .frame(width: 350, height: 120)
                    .foregroundColor(.Morado)

                Text("En este foro los usuarios comparten experiancias positivas sobre cómo el dinero digital, a traves de la aplicació de Banorte, ha mejorado su manejo financiero y les ha brindado nuevas oportunidades de ahorro e inversión, generando un impacto significativo en su bienestar económico y calidad de vida.")
                    .foregroundStyle(Color.white)
                    .frame(width: 325, height: 100)
                    .font(.custom("Poppins-Medium", size: 10))
                    .multilineTextAlignment(.center)
            }.position(x: UISW * 0.5, y: UISH * 0.31)
            
            Text("Testimonios")
                .foregroundStyle(Color.black)
                .font(.custom("Poppins-Bold", size: 16))
                .position(x: UISW * 0.19, y: UISH * 0.44)

            Circle()
                .stroke(Color.Rojo.opacity(0.14) , lineWidth: 35)
                .frame(width: 210, height: 210)
                .position(x: UISW * 0.996, y: UISH * 0.7)
            
            ScrollView{
                
                VStack{
                   
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 350, height: 120)
                        .foregroundColor(.white)
                        .padding(.bottom)
                        .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                        .overlay{
                            ZStack{
                                Image("face1")
                                    .resizable()
                                    .frame(width: 65, height: 65)
                                    .position(x:UISW * 0.12, y: UISH * 0.067 )
                                
                                VStack{
                                    Text("De vivir al día a día a construir un futuro seguro")
                                        .font(.custom("Poppins-Bold", size: 10))
                                        .position(x: UISW * 0.34, y: UISH * 0.035)
                                        .foregroundColor(.black)

                                    
                                    Text("Lizeth Rodriguez, 21 años")
                                        .font(.custom("Poppins-Bold", size: 9))
                                        .foregroundColor(.black)
                                        .position(x: UISW * 0.175, y: UISH * 0.001)
                                    
                                    Text("Cuando descargué la app de Banorte mi vida financiera dio un giro completo. Antes siempre luchaba para llegar al fin de mes y no tenia ahorros para emergencias...")
                                        .font(.custom("Poppins-Regular", size: 9))
                                        .foregroundColor(.black)
                                        .frame(width: 240)
                                        .position(x: UISW * 0.335, y: UISH * -0.012)
                                    
                                }.position(x:UISW * 0.64, y: UISH * 0.065 )
                                
                                ZStack{
                                    RoundedRectangle(cornerRadius: 6)
                                        .frame(width: 75, height: 25)
                                        .foregroundColor(Color.Rojo)
                                    
                                    Text("Leer mas")
                                        .font(.custom("Poppins-Regular", size: 9))
                                        .foregroundStyle(Color.white)
                                }.position(x: UISW * 0.765, y: UISH * 0.14)
                            }
                        }
                    
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 350, height: 120)
                        .foregroundColor(.white)
                        .padding(.bottom)
                        .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                        .overlay{
                            ZStack{
                                Image("face2")
                                    .resizable()
                                    .frame(width: 65, height: 65)
                                    .position(x:UISW * 0.12, y: UISH * 0.067 )
                                
                                VStack{
                                    Text("Cómo el dinero digital cambió mi perspectiva")
                                        .font(.custom("Poppins-Bold", size: 10))
                                        .foregroundColor(.black)
                                        .position(x: UISW * 0.331, y: UISH * 0.035)
                                    
                                    Text("Chema Padilla, 22 años")
                                        .font(.custom("Poppins-Bold", size: 9))
                                        .foregroundColor(.black)
                                        .position(x: UISW * 0.17, y: UISH * 0.001)
                                    
                                    Text("Solía ser bastante escéptico sobre el dinero digital, preocupado por la seguridad y prefiriendo pagar en efectivo...")
                                        .font(.custom("Poppins-Regular", size: 9))
                                        .foregroundColor(.black)
                                        .frame(width: 240)
                                        .position(x: UISW * 0.335, y: UISH * -0.012)
                                    
                                }.position(x:UISW * 0.64, y: UISH * 0.065 )
                                
                                ZStack{
                                    RoundedRectangle(cornerRadius: 6)
                                        .frame(width: 75, height: 25)
                                        .foregroundColor(Color.Rojo)
                                    
                                    Text("Leer mas")
                                        .font(.custom("Poppins-Regular", size: 9))
                                        .foregroundStyle(Color.white)
                                }.position(x: UISW * 0.765, y: UISH * 0.14)
                                
                                
                                    
                            }
                        }

                    
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 350, height: 120)
                        .foregroundColor(.white)
                        .padding(.bottom)
                        .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                        .overlay{
                            ZStack{
                                Image("face3")
                                    .resizable()
                                    .frame(width: 65, height: 65)
                                    .position(x:UISW * 0.12, y: UISH * 0.067 )
                                
                                VStack{
                                    Text("De novato a invesor en pequeños pasos")
                                        .font(.custom("Poppins-Bold", size: 10))
                                        .foregroundColor(.black)
                                        .position(x: UISW * 0.29, y: UISH * 0.035)
                                    
                                    Text("Manuel Laparra, 26 años")
                                        .font(.custom("Poppins-Bold", size: 9))
                                        .foregroundColor(.black)
                                        .position(x: UISW * 0.175, y: UISH * 0.001)
                                    
                                    Text("Siempre fui reacio a invertir mi dinero, sintiéndome abrumado por la complejidad del mercado financiero. Pero al descargar la aplicación de Banorte...")
                                        .font(.custom("Poppins-Regular", size: 9))
                                        .foregroundColor(.black)
                                        .frame(width: 240)
                                        .position(x: UISW * 0.335, y: UISH * -0.012)
                                    
                                }.position(x:UISW * 0.64, y: UISH * 0.065 )
                                
                                ZStack{
                                    RoundedRectangle(cornerRadius: 6)
                                        .frame(width: 75, height: 25)
                                        .foregroundColor(Color.Rojo)
                                    
                                    Text("Leer mas")
                                        .font(.custom("Poppins-Regular", size: 9))
                                        .foregroundStyle(Color.white)
                                }.position(x: UISW * 0.765, y: UISH * 0.14)
                            }
                        }
                    
                    RoundedRectangle(cornerRadius: 10)
                        .frame(width: 350, height: 120)
                        .foregroundColor(.white)
                        .padding(.bottom)
                        .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                        .overlay{
                            ZStack{
                                Image("face4")
                                    .resizable()
                                    .frame(width: 65, height: 65)
                                    .position(x:UISW * 0.12, y: UISH * 0.067 )
                                
                                VStack{
                                    Text("Cuánto logré ahorrar usando dinero digital")
                                        .font(.custom("Poppins-Bold", size: 10))
                                        .foregroundColor(.black)
                                        .position(x: UISW * 0.315, y: UISH * 0.035)
                                    
                                    Text("Michelle López, 46 años")
                                        .font(.custom("Poppins-Bold", size: 9))
                                        .position(x: UISW * 0.175, y: UISH * 0.001)
                                    
                                    Text("Antes solía perder el control de mis gastos con el efectivo, pero desde que comencé a utilizar aplicaciones de pago móvil como CoDi, DiMO...")
                                        .font(.custom("Poppins-Regular", size: 9))
                                        .foregroundColor(.black)
                                        .frame(width: 240)
                                        .position(x: UISW * 0.32, y: UISH * -0.012)
                                    
                                }.position(x:UISW * 0.64, y: UISH * 0.065 )
                                
                                ZStack{
                                    RoundedRectangle(cornerRadius: 6)
                                        .frame(width: 75, height: 25)
                                        .foregroundColor(Color.Rojo)
                                    
                                    Text("Leer mas")
                                        .font(.custom("Poppins-Regular", size: 9))
                                        .foregroundStyle(Color.white)
                                }.position(x: UISW * 0.765, y: UISH * 0.14)
                                
                                
                                    
                            }
                        }
                    
                    Rectangle()
                        .foregroundColor(.clear)
                        .frame(width: UISW, height: 550)
                }
                
            }.frame(height: 350)
            .position(x: UISW * 0.5, y: UISH * 0.68)
            
            
        }.ignoresSafeArea(.all)
    }
}

#Preview {
    ContentView()
}
