//
//  ContentView.swift
//  perfil
//
//  Created by Michelle Ayala on 24/04/24.
//

import SwiftUI

struct ProfileView: View {
    
    private var UISW: CGFloat = UIScreen.main.bounds.width
    private var UISH: CGFloat = UIScreen.main.bounds.height
    
    var body: some View {
        ZStack{
        Color(uiColor: UIColor(red: 0.96, green: 0.96, blue: 0.96, alpha: 1.00))
                .ignoresSafeArea()
            
            Image("circulo-esquina")
                .resizable()
                .frame(width: 150, height: 150)
                .position(x: UISW * 0.1, y: UISH * 0.0)
            
            Group {
                
                VStack (spacing: 6){
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.5)
                        .frame(width: 8)
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.5)
                        .frame(width: 8)
                    Circle()
                        .foregroundColor(.gray)
                        .opacity(0.5)
                        .frame(width: 8)
                }
            }
            .position(x: UISW * 0.9, y: UISH * 0.02)
            
            Image("circulo-borde")
                .resizable()
                .frame(width: UISW * 0.25 , height: UISH * 0.25)
                .position(x: UISW * 0.9, y: UISH * 0.7)
       
            
            VStack (spacing: 25)  {
                
                Text("Perfil")
                    .font(.custom("Poppins-Bold", size: 30))
                    .foregroundColor(.black)

                Image("mich-face")
                    .resizable()
                    .frame(width: UISW * 0.46, height: UISH * 0.21)
                
                Text("Michelle Ayala")
                    .font(.custom("Poppins-Bold", size: 25))
                    .foregroundColor(.black)
                
                HStack(alignment: .center, spacing: 30) {
                    Text("Monterrey")
                        .foregroundColor(.black)
                    Text("21 años")
                        .foregroundColor(.black)
                }
                .font(.custom("Poppins-Regular", size: 15))
                .padding(-10)
                
                VStack{
                    Group {
                        RoundedRectangle(cornerRadius: 20)
                        .frame(width: 350, height: 90)
                        .foregroundColor(.white)
                        .padding(.bottom)
                        .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                        .padding(.top, 35)
                        .overlay {
                            
                            Text("Progreso")
                            .font(.custom("Poppins-Bold", size: 16))
                            .foregroundColor(.black)
                            .position(x: UISW * 0.162, y: UISH * 0.078)
                            
                                ZStack {
                                    RoundedRectangle(cornerRadius: 20)
                                        .frame(width: 260, height: 10)
                                        .foregroundColor(.gray)
                                        .opacity(0.2)
                                        .position(x: UISW * 0.4, y: UISH * 0.11)

                                    
                                    RoundedRectangle(cornerRadius: 20)
                                        .frame(width: 220, height: 10)
                                        .foregroundColor(.Rojo)
                                        .position(x: UISW * 0.35, y: UISH * 0.11)
                                    
                                
                                Text("90%")
                                        .foregroundColor(.black)
                                        .position(x: UISW * 0.8, y: UISH * 0.11)

                            }
                        }
   
                    }
                    
                    Group {
                        RoundedRectangle(cornerRadius: 20)
                        .frame(width: 350, height: 170)
                        .foregroundColor(.white)
                        .padding(.bottom)
                        .shadow(color: Color.gray.opacity(0.2), radius: 2, x: 0, y: 5)
                        .overlay {
                            Text("Puntos obtenidos")
                            .font(.custom("Poppins-Bold", size: 16))
                            .foregroundColor(.black)
                            .position(x: UISW * 0.25, y: UISH * 0.04)
                            
                            HStack {
                                
                                Text("Los puntos obtenidos durante la realización del curso sobre educación financiera se abonarán a su Banorte Móvil al momento que finalice todo y contrate su primera cuenta con nosotros ")
                                    .font(.custom("Poppins-Medium", size: 12))
                                    .foregroundColor(.black)
                                    .frame(width: 210, height: 100)
                                    .padding(.top, 20)
                                VStack {
                                    Image("monedas")
                                        .resizable()
                                        .frame(width: 70, height: 60)
                                    Text("120 puntos")
                                        .font(.custom("Poppins-Bold", size: 12))
                                        .foregroundColor(.black)

                                }
                                
                            }
                            .position(x: UISW * 0.43, y: UISH * 0.1)

                            
                        }
                                    
                    }
                    

                }
                .padding(.top, -10)
                
                
            }
            .padding(.bottom, 30)
            //.position(x: UISW * 0.01, y: UISH * 0.05)
        }
    }
}

#Preview {
    ProfileView()
}
